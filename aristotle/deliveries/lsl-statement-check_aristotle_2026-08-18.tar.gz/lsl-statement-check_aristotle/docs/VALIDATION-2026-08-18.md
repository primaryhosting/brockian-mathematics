# LargeSieveLib v0.2 — statement contract elaboration check

Date: 2026-08-18. Scope: **validation only**. No theorem was proved, no
mathematical content of any statement was altered, and the two intentional
trusted-contract `sorry`s in `Statement/LargeSieve.lean` are still in place.

## Verdict

**PASS.** Every definition in `Statement/Defs.lean` and both theorem
*statements* in `Statement/LargeSieve.lean` elaborate against Mathlib.

`lake build Statement` completes successfully (8029 jobs). The only diagnostics
emitted by the two challenge modules are exactly the two expected placeholders:

```
warning: Statement/LargeSieve.lean:32:8: declaration uses `sorry`
warning: Statement/LargeSieve.lean:46:8: declaration uses `sorry`
```

There are no unknown identifiers, no typeclass/instance resolution failures, and
no unification/coercion errors in either module.

## One blocker found, and its repair (build configuration only)

**Blocker T-1 — unsatisfiable toolchain/dependency pin.**

As delivered, `lean-toolchain` read `leanprover/lean4:v4.32.0` and
`lakefile.toml` required `mathlib` at `rev = "v4.32.0"`, but the dependency set
actually checked out under `.lake/packages` is the Mathlib `v4.28.0` tag
(`8f9d9cff6bd728b17a24e163c9402775d9e6a365`), whose own `lean-toolchain` is
`leanprover/lean4:v4.28.0`. Building the v4.28 sources of Batteries / Aesop /
Qq / Plausible / Mathlib with the v4.32 compiler fails long before reaching
`Statement`, e.g.

```
error: Batteries/Data/Nat/Basic.lean:95:4: `Nat.sqrt` has already been declared
error: Batteries/Tactic/Exact.lean:25:0: Invalid definition `MVarId.assignIfDefeq`, ...
error: Aesop/Util/EqualUpToIds.lean:90:12: Invalid field `lDepth`: ...
error: Plausible/Testable.lean:378:67: Application type mismatch: ...
error: Qq/Delab.lean:74:9: Type mismatch
error: Mathlib/Tactic/Linter/Header.lean:365:23: Type mismatch
```

None of these come from the challenge modules; they are pure toolchain skew.

*Minimal repair applied* (no `.lean` statement touched):

* `lean-toolchain`: `leanprover/lean4:v4.32.0` → `leanprover/lean4:v4.28.0`
* `lakefile.toml`: mathlib `rev = "v4.32.0"` → `rev = "v4.28.0"`

If your CI genuinely pins Lean v4.32.0, the equivalent repair in the other
direction is to advance the vendored Mathlib checkout to a v4.32.0-compatible
revision; the statement surface below uses no API that is known to have moved
between those releases, so either direction should be statement-preserving —
but only the v4.28.0 direction was actually elaborated here.

## Specific concerns raised, checked individually

### 1. `Fintype (DirichletCharacter ℂ q)` at a bound modulus without `NeZero q`

**Not an issue.** The instance is total in the modulus:

```
DirichletCharacter.fintype :
  {R : Type u_1} → [CommRing R] → [IsDomain R] → {n : ℕ} → Fintype (DirichletCharacter R n)
  := fun {R} _ _ {n} => Fintype.ofFinite (DirichletCharacter R n)
```

It carries no `NeZero n` hypothesis. So the inner sum in
`multiplicative_large_sieve`, where `q` is bound by `∑ q ∈ Finset.Icc 1 Q`,
resolves without any side condition. Note the instance is `noncomputable`; that
is harmless in a `Prop`-valued statement.

### 2. Decidability of the primitivity filter

**Load-bearing, and already correctly handled.** `Finset.univ.filter
(fun χ : DirichletCharacter ℂ q => χ.IsPrimitive)` needs
`DecidablePred (·.IsPrimitive)`, which Mathlib does not provide. The
`open scoped Classical in` on `multiplicative_large_sieve` supplies it. Removing
that line reproduces:

```
failed to synthesize instance of type class
  DecidablePred fun χ => χ.IsPrimitive
```

So the `open scoped Classical in` must stay. (No `DecidableEq (DirichletCharacter ℂ q)`
instance exists either, which is a second reason to keep it.)

### 3. `ZMod.stdAddChar`-free statement surface

**Clean.** The additive side is phrased entirely through the project's own
`LargeSieve.e x = Complex.exp (2 * Real.pi * Complex.I * x)` and `distZ`; no
`ZMod.stdAddChar`, `AddChar`, or `ZMod.exp` API is referenced anywhere in the
two modules, so no instance obligations on the modulus arise on the additive
side at all.

### 4. Coercions

All elaborate as intended:

* `centre M N = ((M + (N + 1) / 2 : ℕ) : ℝ)` — the `(N + 1) / 2` is ℕ-division
  performed before the cast, so `centre` is integer-valued as the docstring
  claims (spot-checked: `centre 3 4 = 5`).
* `charSum` elaborates at
  `(ℕ → ℂ) → ℕ → ℕ → (q : ℕ) → DirichletCharacter ℂ q → ℂ`, with `χ n`
  inserting `ℕ → ZMod q` on the argument and the `MulChar` fun-coercion on `χ`.
* In both headline bounds `N` and `Q` are cast `ℕ → ℝ`, and the whole
  inequality lives in `ℝ`.

### Elaborated statement types (for comparator diffing)

```
additive_large_sieve : ∀ (a : ℕ → ℂ) (M N : ℕ) (T : Finset ℝ) (δ : ℝ),
  0 < δ → δ ≤ 1 → IsSpaced T δ →
    ∑ α ∈ T, ‖expSumC a M N α‖ ^ 2 ≤ (2 * Real.pi * ↑N + 1 / δ) * coeffMass a M N

multiplicative_large_sieve : ∀ (a : ℕ → ℂ) (M N Q : ℕ), 0 < Q →
  ∑ q ∈ Finset.Icc 1 Q, ↑q / ↑q.totient * ∑ χ with χ.IsPrimitive, ‖charSum a M N q χ‖ ^ 2
    ≤ (2 * Real.pi * ↑N + ↑Q ^ 2) * coeffMass a M N
```

## Non-blocking observations (no action taken)

* `hδ1 : δ ≤ 1` in `additive_large_sieve` and `hQ : 0 < Q` in
  `multiplicative_large_sieve` are part of the trusted contract but are not
  needed for the statements to elaborate. They are kept verbatim.
* `fareySet` is defined but not referenced by either headline theorem; it
  elaborates fine (`fareySet : ℕ → Finset ℝ`).
* `expSumCDeriv` is likewise defined but unused in this module; it elaborates.
* The docstring on `expSumC` claims `Function.Periodic (expSumC a M N) 1` and
  `‖S_C(α)‖ = ‖S(α)‖`, naming lemmas `expSumC_periodic` / `norm_expSumC`. Those
  lemmas do not exist in this trusted module (by design — they belong to the
  solution library). Their truth was **not** checked here; that is outside the
  elaboration-only scope of this pass.

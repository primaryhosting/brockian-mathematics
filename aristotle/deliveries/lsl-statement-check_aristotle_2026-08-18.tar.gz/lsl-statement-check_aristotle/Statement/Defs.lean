/-
Copyright 2026 The LargeSieveLib contributors.
Released under Apache 2.0 license as described in the file LICENSE.

Statement/Defs.lean — shared trusted definitions for the large-sieve contract.

STATUS: v0.2 contract-repair draft (2026-08-18). These definitions incorporate
the fixes mandated by docs/AUDIT-2026-08-18.md:
  * `centre` is integer-valued (audit Blocker B) — real division of naturals in
    the old `M + (N + 1) / 2` made `expSumC` anti-periodic for even N.
ELABORATION-CHECKED 2026-08-18: `lake build Statement` succeeds; every
definition here and both theorem statements in `Statement/LargeSieve.lean`
typecheck against Mathlib. See docs/VALIDATION-2026-08-18.md (this required a
build-configuration repair to the toolchain/Mathlib pin; no statement changed).
-/
import Mathlib

open scoped BigOperators

namespace LargeSieve

/-- Distance from a real number to the nearest integer (distance on ℝ/ℤ). -/
noncomputable def distZ (x : ℝ) : ℝ := |x - round x|

/-- Integer-valued centre of the summation window `M < n ≤ M + N`.

The division `(N + 1) / 2` is ℕ-division, performed BEFORE the cast to ℝ, so
`centre M N` is always an integer. This is the audit's Blocker-B repair: with a
half-integer centre (even `N`), `expSumC` is anti-periodic (`T(α+1) = -T(α)`)
and `Function.Periodic (expSumC a M N) 1` is FALSE. The integer centre restores
1-periodicity and still gives `|n - centre M N| ≤ N / 2 + 1` for `M < n ≤ M + N`
(and `|n - centre M N| ≤ (N+1)/2` exactly), which suffices for the derivative
bound with the conservative `2πN` headline constant. -/
def centre (M N : ℕ) : ℝ := ((M + (N + 1) / 2 : ℕ) : ℝ)

/-- `e x = exp(2πix)`, the standard additive character of ℝ/ℤ. -/
noncomputable def e (x : ℝ) : ℂ := Complex.exp (2 * Real.pi * Complex.I * x)

/-- Total coefficient mass `∑_{M < n ≤ M+N} ‖a n‖²`. -/
noncomputable def coeffMass (a : ℕ → ℂ) (M N : ℕ) : ℝ :=
  ∑ n ∈ Finset.Ioc M (M + N), ‖a n‖ ^ 2

/-- Uncentered exponential sum `S(α) = ∑_{M < n ≤ M+N} a_n e(nα)`. -/
noncomputable def expSum (a : ℕ → ℂ) (M N : ℕ) (α : ℝ) : ℂ :=
  ∑ n ∈ Finset.Ioc M (M + N), a n * e ((n : ℝ) * α)

/-- Centered exponential sum `S_C(α) = ∑_{M < n ≤ M+N} a_n e((n − ν)α)`,
`ν = centre M N` (integer-valued, see `centre`). `‖S_C(α)‖ = ‖S(α)‖`
(`norm_expSumC`) and `S_C` is 1-periodic (`expSumC_periodic`). -/
noncomputable def expSumC (a : ℕ → ℂ) (M N : ℕ) (α : ℝ) : ℂ :=
  ∑ n ∈ Finset.Ioc M (M + N), a n * e (((n : ℝ) - centre M N) * α)

/-- Explicit derivative of `expSumC` in `α`. -/
noncomputable def expSumCDeriv (a : ℕ → ℂ) (M N : ℕ) (α : ℝ) : ℂ :=
  ∑ n ∈ Finset.Ioc M (M + N),
    (2 * Real.pi * Complex.I * ((n : ℂ) - (centre M N : ℂ))) * a n *
      e (((n : ℝ) - centre M N) * α)

/-- A finite set of points is δ-spaced modulo 1. -/
def IsSpaced (T : Finset ℝ) (δ : ℝ) : Prop :=
  ∀ α ∈ T, ∀ β ∈ T, α ≠ β → δ ≤ distZ (α - β)

/-- The Farey points `a / q` with `1 ≤ q ≤ Q`, `0 ≤ a < q`, `gcd(a, q) = 1`,
regarded as real numbers in `[0, 1)`. -/
noncomputable def fareySet (Q : ℕ) : Finset ℝ := by
  classical
  exact (Finset.Icc 1 Q).biUnion fun q =>
    ((Finset.range q).filter fun a => Nat.Coprime a q).image fun a => (a : ℝ) / q

/-- Character sum `∑_{M < n ≤ M+N} a_n χ(n)` for a Dirichlet character mod q. -/
noncomputable def charSum (a : ℕ → ℂ) (M N q : ℕ) (χ : DirichletCharacter ℂ q) : ℂ :=
  ∑ n ∈ Finset.Ioc M (M + N), a n * χ n

end LargeSieve

/-
Copyright 2026 The LargeSieveLib contributors.
Released under Apache 2.0 license as described in the file LICENSE.

Statement/LargeSieve.lean — the trusted theorem contract (challenge module).

The two `sorry`s below are the 2 INTENTIONAL trusted-contract placeholders:
this module states the headline theorems and is never proved here. Comparator
builds this environment as the trusted challenge and compares statements
against the untrusted solution environment `LargeSieveLib`.

v0.2 CONSTANT DECISION (audit §2A, "fast conservative repair"):
the headline constants are `2πN + 1/δ` and `2πN + Q²`, consistent with the
existing arbitrary-point `gallagher_sum` shape
  ∑‖f(α)‖² ≤ δ⁻¹A + 2√A√B  with  B ≤ π²N²A.
The sharper centered-interval `πN + 1/δ` refinement (audit's preferred repair
path via centered arcs) is the v0.3 target; see README and docs/ROADMAP.md.
-/
import Statement.Defs

open scoped BigOperators

namespace LargeSieve

/-- **Additive large sieve** (v0.2 conservative constant).

For any δ-spaced finite set `T` of points modulo 1,

  ∑_{α ∈ T} ‖S_C(α)‖² ≤ (2πN + δ⁻¹) · ∑ ‖a_n‖².

Trusted-contract placeholder: to be proved in the solution library, never here. -/
theorem additive_large_sieve
    (a : ℕ → ℂ) (M N : ℕ) (T : Finset ℝ) (δ : ℝ)
    (hδ : 0 < δ) (hδ1 : δ ≤ 1) (hT : IsSpaced T δ) :
    ∑ α ∈ T, ‖expSumC a M N α‖ ^ 2
      ≤ (2 * Real.pi * N + 1 / δ) * coeffMass a M N := by
  sorry -- trusted-contract placeholder (challenge statement)

open scoped Classical in
/-- **Multiplicative large sieve** (v0.2 conservative constant).

  ∑_{q ≤ Q} (q/φ(q)) ∑*_{χ mod q primitive} ‖∑ a_n χ(n)‖²
    ≤ (2πN + Q²) · ∑ ‖a_n‖².

Trusted-contract placeholder: to be proved in the solution library, never here. -/
theorem multiplicative_large_sieve
    (a : ℕ → ℂ) (M N Q : ℕ) (hQ : 0 < Q) :
    ∑ q ∈ Finset.Icc 1 Q,
      ((q : ℝ) / (Nat.totient q : ℝ)) *
        ∑ χ ∈ Finset.univ.filter (fun χ : DirichletCharacter ℂ q => χ.IsPrimitive),
          ‖charSum a M N q χ‖ ^ 2
      ≤ (2 * Real.pi * N + (Q : ℝ) ^ 2) * coeffMass a M N := by
  sorry -- trusted-contract placeholder (challenge statement)

end LargeSieve
